Ethiopia
This map shows the boundaries of the administrative areas
in raw WGS84 latitude and longitude coordinates.
The files are in "Map Maker" DRA format.
